'use strict';

const form = document.querySelector('#destination-form');
const statusElement = document.querySelector('#status');
const captureLocationButton = document.querySelector('#capture-location');
const locationSummary = document.querySelector('#location-summary');
const destinationsList = document.querySelector('#destinations');

function setStatus(message, type = '') {
  statusElement.textContent = message;
  statusElement.className = type;
}

async function getSettings() {
  const stored = await chrome.storage.local.get(DeliveryGuard.SETTINGS_KEY);
  return stored[DeliveryGuard.SETTINGS_KEY] || { destinations: [] };
}

async function saveSettings(settings) {
  await chrome.storage.local.set({ [DeliveryGuard.SETTINGS_KEY]: settings });
}

function renderDestination(destination) {
  const item = document.createElement('li');
  const copy = document.createElement('div');
  copy.className = 'destination-copy';
  const name = document.createElement('strong');
  name.textContent = destination.name;
  const detail = document.createElement('span');
  detail.textContent = `半径 ${destination.radiusMeters}m / 識別子: ${destination.addressMatchers.join('、')}`;
  copy.append(name, detail);
  const removeButton = document.createElement('button');
  removeButton.type = 'button';
  removeButton.className = 'danger';
  removeButton.textContent = '削除';
  removeButton.addEventListener('click', async () => {
    const settings = await getSettings();
    settings.destinations = settings.destinations.filter((saved) => saved.id !== destination.id);
    await saveSettings(settings);
    await render();
    setStatus(`「${destination.name}」を削除しました。`, 'success');
  });
  item.append(copy, removeButton);
  return item;
}

async function render() {
  const settings = await getSettings();
  destinationsList.replaceChildren();
  if (settings.destinations.length === 0) {
    const empty = document.createElement('li');
    empty.textContent = '登録済みの配送先はありません。';
    destinationsList.append(empty);
    return;
  }
  settings.destinations.forEach((destination) => destinationsList.append(renderDestination(destination)));
}

captureLocationButton.addEventListener('click', async () => {
  captureLocationButton.disabled = true;
  setStatus('現在地を取得しています…');
  try {
    const location = await chrome.runtime.sendMessage({ type: 'GET_CURRENT_LOCATION' });
    if (!location?.ok) throw new Error(location?.error || '位置情報を取得できませんでした。');
    form.elements.latitude.value = String(location.latitude);
    form.elements.longitude.value = String(location.longitude);
    locationSummary.textContent = `取得済み（精度 約${Math.round(location.accuracyMeters)}m、${new Date(location.capturedAt).toLocaleString('ja-JP')}）`;
    setStatus('現在地を取得しました。', 'success');
  } catch (error) {
    setStatus(error.message, 'error');
  } finally {
    captureLocationButton.disabled = false;
  }
});

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const destination = {
    id: crypto.randomUUID(),
    name: form.elements.name.value.trim(),
    addressMatchers: form.elements.matchers.value.split(/\r?\n/).map((value) => value.trim()).filter(Boolean),
    radiusMeters: Number(form.elements.radius.value),
    latitude: Number(form.elements.latitude.value),
    longitude: Number(form.elements.longitude.value)
  };
  if (!DeliveryGuard.isValidDestination(destination)) {
    setStatus('場所名、3文字以上の識別子、50〜100,000mの半径、現在地を正しく入力してください。', 'error');
    return;
  }
  const settings = await getSettings();
  settings.destinations.push(destination);
  await saveSettings(settings);
  form.reset();
  locationSummary.textContent = '現在地をまだ取得していません。';
  await render();
  setStatus(`「${destination.name}」を保存しました。`, 'success');
});

render().catch((error) => setStatus(error.message, 'error'));
