'use strict';

function getPosition() {
  return new Promise((resolve) => {
    navigator.geolocation.getCurrentPosition(
      (position) => resolve({
        ok: true,
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
        accuracyMeters: position.coords.accuracy,
        capturedAt: new Date().toISOString()
      }),
      (error) => resolve({ ok: false, error: error.message || '位置情報の利用が許可されていません。' }),
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 120000 }
    );
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.target !== 'offscreen' || message.type !== 'GET_CURRENT_LOCATION') return;
  getPosition().then(sendResponse);
  return true;
});
