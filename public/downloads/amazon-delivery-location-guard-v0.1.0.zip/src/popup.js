'use strict';

const summary = document.querySelector('#summary');
const openOptionsButton = document.querySelector('#open-options');

async function render() {
  const stored = await chrome.storage.local.get(DeliveryGuard.SETTINGS_KEY);
  const settings = stored[DeliveryGuard.SETTINGS_KEY] || DeliveryGuard.DEFAULT_SETTINGS;
  const count = settings.destinations?.length || 0;
  summary.textContent = count === 0
    ? '登録済みの配送先がありません。最初に場所を登録してください。'
    : `${count}件の配送先を登録済みです。Amazon の注文確認画面で照合します。`;
}

openOptionsButton.addEventListener('click', () => chrome.runtime.openOptionsPage());
render().catch(() => { summary.textContent = '設定を読み込めませんでした。'; });
