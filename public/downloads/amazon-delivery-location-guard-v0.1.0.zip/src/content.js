(function deliveryGuardContentScript() {
  'use strict';

  const PANEL_ID = 'delivery-location-guard-modal';
  const CONFIRMATION_PREFIX = 'delivery-location-guard-confirmed:';
  let latestAssessment = { status: 'not-checked' };
  let checkInProgress = false;
  let scheduledCheck;

  function isCheckoutPage() {
    const path = `${location.pathname}${location.search}`.toLowerCase();
    return /checkout|gp\/buy|\/buy\/|spc\//.test(path);
  }

  function getConfirmationId() {
    return latestAssessment.status === 'mismatch'
      ? latestAssessment.deliveryDestination.id
      : latestAssessment.status;
  }

  function wasConfirmed() {
    return sessionStorage.getItem(`${CONFIRMATION_PREFIX}${getConfirmationId()}`) === 'true';
  }

  function confirmAssessment() {
    sessionStorage.setItem(`${CONFIRMATION_PREFIX}${getConfirmationId()}`, 'true');
    renderAssessment();
  }

  function formatDistance(meters) {
    return meters >= 1000 ? `${(meters / 1000).toFixed(1)}km` : `${meters}m`;
  }

  function getOrCreateModal() {
    let panel = document.querySelector(`#${PANEL_ID}`);
    if (panel) return panel;
    panel = document.createElement('div');
    panel.id = PANEL_ID;
    panel.style.cssText = [
      'align-items:center', 'background:rgba(10,20,38,.72)', 'box-sizing:border-box', 'display:flex',
      'inset:0', 'justify-content:center', 'padding:20px', 'position:fixed', 'z-index:2147483647'
    ].join(';');
    document.documentElement.append(panel);
    return panel;
  }

  function createText(tag, value, styles = '') {
    const element = document.createElement(tag);
    element.textContent = value;
    element.style.cssText = styles;
    return element;
  }

  function renderAssessment() {
    const existingPanel = document.querySelector(`#${PANEL_ID}`);
    if (latestAssessment.status === 'match' || latestAssessment.status === 'not-checked' || wasConfirmed()) {
      existingPanel?.remove();
      return;
    }

    const panel = getOrCreateModal();
    panel.replaceChildren();
    const dialog = document.createElement('section');
    dialog.setAttribute('role', 'alertdialog');
    dialog.setAttribute('aria-modal', 'true');
    dialog.setAttribute('aria-labelledby', `${PANEL_ID}-title`);
    dialog.style.cssText = [
      'background:#fff', 'border-radius:18px', 'box-shadow:0 20px 60px rgba(0,0,0,.38)',
      'box-sizing:border-box', 'color:#172033', 'font:18px/1.6 system-ui,-apple-system,sans-serif',
      'max-width:620px', 'padding:34px', 'width:100%'
    ].join(';');
    const icon = createText('div', '!', 'align-items:center;background:#b42318;border-radius:50%;color:#fff;display:flex;font-size:27px;font-weight:800;height:46px;justify-content:center;margin-bottom:16px;width:46px');
    dialog.append(icon);

    let title;
    let message;
    if (latestAssessment.status === 'mismatch') {
      const { deliveryDestination, distanceMeters } = latestAssessment;
      title = '配送先が現在地と違う可能性があります';
      message = `配送先は「${deliveryDestination.name}」として登録されています。現在地から約 ${formatDistance(distanceMeters)} 離れています。`;
    } else if (latestAssessment.status === 'delivery-unknown') {
      title = '配送先を確認してください';
      message = 'この画面の配送先を、登録済みの場所として特定できませんでした。Amazonの配送先欄を確認してから、購入を続けてください。';
    } else {
      title = '現在地を確認できません';
      message = '位置情報を取得できなかったため、配送先との照合は行えませんでした。Amazonの配送先欄を確認してから、購入を続けてください。';
    }

    const titleElement = createText('h1', title, 'font-size:27px;line-height:1.35;margin:0 0 14px');
    titleElement.id = `${PANEL_ID}-title`;
    const messageElement = createText('p', message, 'color:#3b4658;margin:0 0 18px');
    const notice = createText('p', '配送先を確認したうえで進む場合は「了解です」を押してください。', 'background:#fff4e5;border-radius:8px;font-size:15px;font-weight:700;margin:0 0 24px;padding:12px');
    const button = document.createElement('button');
    button.type = 'button';
    button.textContent = '了解です';
    button.style.cssText = 'background:#b42318;border:0;border-radius:8px;color:#fff;cursor:pointer;font:inherit;font-size:18px;font-weight:800;min-height:50px;padding:10px 28px;width:100%';
    button.addEventListener('click', confirmAssessment);
    dialog.append(titleElement, messageElement, notice, button);
    panel.append(dialog);
    button.focus();
  }

  async function checkDeliveryLocation() {
    if (!isCheckoutPage() || checkInProgress) return;
    checkInProgress = true;
    try {
      const stored = await chrome.storage.local.get(DeliveryGuard.SETTINGS_KEY);
      const destinations = stored[DeliveryGuard.SETTINGS_KEY]?.destinations || [];
      if (destinations.length === 0) {
        latestAssessment = { status: 'not-checked' };
        renderAssessment();
        return;
      }
      const pageText = document.body?.innerText || '';
      const destination = DeliveryGuard.findDeliveryDestination(pageText, destinations);
      if (!destination) {
        latestAssessment = { status: 'delivery-unknown' };
        renderAssessment();
        return;
      }
      const locationResult = await chrome.runtime.sendMessage({ type: 'GET_CURRENT_LOCATION' });
      latestAssessment = DeliveryGuard.assessDelivery(
        locationResult?.ok ? locationResult : null,
        pageText,
        destinations
      );
      renderAssessment();
    } catch (error) {
      latestAssessment = { status: 'location-unavailable' };
      renderAssessment();
    } finally {
      checkInProgress = false;
    }
  }

  function scheduleCheck() {
    clearTimeout(scheduledCheck);
    scheduledCheck = setTimeout(checkDeliveryLocation, 500);
  }

  function isOrderConfirmationControl(target) {
    const control = target.closest('button, input[type="submit"], input[type="button"], a[role="button"]');
    if (!control) return false;
    const label = `${control.textContent || ''} ${control.value || ''} ${control.getAttribute('aria-label') || ''}`.toLowerCase();
    return /注文を確定|注文する|place your order|place order|buy now/.test(label);
  }

  document.addEventListener('click', (event) => {
    if (latestAssessment.status === 'match' || latestAssessment.status === 'not-checked' || wasConfirmed()) return;
    if (!isOrderConfirmationControl(event.target)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    renderAssessment();
    renderAssessment();
  }, true);

  function mutationIsOutsideGuardPanel(mutation) {
    const targetElement = mutation.target.nodeType === Node.ELEMENT_NODE
      ? mutation.target
      : mutation.target.parentElement;
    if (targetElement?.closest?.(`#${PANEL_ID}`)) return false;
    if (mutation.type !== 'childList') return true;
    return [...mutation.addedNodes].some((node) => {
      if (node.nodeType !== Node.ELEMENT_NODE) return true;
      return node.id !== PANEL_ID && !node.closest?.(`#${PANEL_ID}`);
    });
  }

  const observer = new MutationObserver((mutations) => {
    if (mutations.some(mutationIsOutsideGuardPanel)) scheduleCheck();
  });
  observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes[DeliveryGuard.SETTINGS_KEY]) scheduleCheck();
  });
  scheduleCheck();
})();
