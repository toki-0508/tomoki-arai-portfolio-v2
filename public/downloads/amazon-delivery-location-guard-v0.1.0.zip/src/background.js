import './shared.js';

const OFFSCREEN_DOCUMENT_PATH = 'src/offscreen.html';
let creatingOffscreenDocument;

async function ensureOffscreenDocument() {
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH)]
  });
  if (existingContexts.length > 0) return;

  if (!creatingOffscreenDocument) {
    creatingOffscreenDocument = chrome.offscreen.createDocument({
      url: OFFSCREEN_DOCUMENT_PATH,
      reasons: ['GEOLOCATION'],
      justification: 'Get the current device location only when checking the active Amazon checkout page.'
    }).finally(() => {
      creatingOffscreenDocument = undefined;
    });
  }
  await creatingOffscreenDocument;
}

async function getCurrentLocation() {
  await ensureOffscreenDocument();
  return chrome.runtime.sendMessage({ target: 'offscreen', type: 'GET_CURRENT_LOCATION' });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== 'GET_CURRENT_LOCATION' || message.target === 'offscreen') return;

  getCurrentLocation()
    .then(sendResponse)
    .catch((error) => sendResponse({ ok: false, error: error.message || '位置情報を取得できませんでした。' }));
  return true;
});
