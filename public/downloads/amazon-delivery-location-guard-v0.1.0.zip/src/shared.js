(function attachShared(globalScope) {
  'use strict';

  const SETTINGS_KEY = 'settings';
  const DEFAULT_SETTINGS = Object.freeze({ destinations: [] });

  function normalizeText(value) {
    return String(value || '')
      .normalize('NFKC')
      .replace(/[\s\-‐‑‒–—―ー]/g, '')
      .toLowerCase();
  }

  function isValidCoordinate(value, min, max) {
    return typeof value === 'number' && Number.isFinite(value) && value >= min && value <= max;
  }

  function isValidDestination(destination) {
    return destination &&
      typeof destination.id === 'string' && destination.id.length > 0 &&
      typeof destination.name === 'string' && destination.name.trim().length > 0 &&
      isValidCoordinate(destination.latitude, -90, 90) &&
      isValidCoordinate(destination.longitude, -180, 180) &&
      typeof destination.radiusMeters === 'number' && destination.radiusMeters >= 50 && destination.radiusMeters <= 100000 &&
      Array.isArray(destination.addressMatchers) &&
      destination.addressMatchers.every((matcher) => typeof matcher === 'string' && normalizeText(matcher).length >= 3);
  }

  function haversineMeters(first, second) {
    const earthRadiusMeters = 6371000;
    const toRadians = (degrees) => degrees * Math.PI / 180;
    const latitudeDelta = toRadians(second.latitude - first.latitude);
    const longitudeDelta = toRadians(second.longitude - first.longitude);
    const a = Math.sin(latitudeDelta / 2) ** 2 +
      Math.cos(toRadians(first.latitude)) * Math.cos(toRadians(second.latitude)) * Math.sin(longitudeDelta / 2) ** 2;
    return 2 * earthRadiusMeters * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  function findDeliveryDestination(pageText, destinations) {
    const normalizedPageText = normalizeText(pageText);
    const matches = destinations.filter((destination) => destination.addressMatchers.some((matcher) =>
      normalizedPageText.includes(normalizeText(matcher))
    ));
    return matches.length === 1 ? matches[0] : null;
  }

  function assessDelivery(location, pageText, destinations) {
    const deliveryDestination = findDeliveryDestination(pageText, destinations);
    if (!deliveryDestination) {
      return { status: 'delivery-unknown' };
    }
    if (!location || !isValidCoordinate(location.latitude, -90, 90) || !isValidCoordinate(location.longitude, -180, 180)) {
      return { status: 'location-unavailable', deliveryDestination };
    }

    const distanceMeters = haversineMeters(location, deliveryDestination);
    const allowedMeters = Math.max(deliveryDestination.radiusMeters, Number(location.accuracyMeters) || 0);
    return {
      status: distanceMeters <= allowedMeters ? 'match' : 'mismatch',
      deliveryDestination,
      distanceMeters: Math.round(distanceMeters),
      allowedMeters: Math.round(allowedMeters)
    };
  }

  const exported = {
    SETTINGS_KEY,
    DEFAULT_SETTINGS,
    normalizeText,
    isValidDestination,
    haversineMeters,
    findDeliveryDestination,
    assessDelivery
  };

  globalScope.DeliveryGuard = exported;
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = exported;
  }
})(typeof globalThis === 'undefined' ? window : globalThis);
